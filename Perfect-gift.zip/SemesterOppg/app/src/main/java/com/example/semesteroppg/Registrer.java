package com.example.semesteroppg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.semesteroppg.ui.Database;


public class Registrer extends AppCompatActivity {
    Button mLoginn, mRegistrer;
    EditText mBrukernavn;
    EditText mPassord;
    EditText mGjentaPassord;
    EditText mNavn;
    EditText mEmail;
    Database db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrer);

        db = new Database(this);
        mLoginn = (Button)findViewById(R.id.button_loginn);
        mBrukernavn = (EditText)findViewById(R.id.editText_brukernavn);
        mPassord = (EditText)findViewById(R.id.editText_passord);
        mGjentaPassord = (EditText)findViewById(R.id.editText_gjentaPassord);
        mRegistrer = (Button)findViewById(R.id.button_nyBruker);
        mNavn = (EditText)findViewById(R.id.editText_Navn);
        mEmail = (EditText)findViewById(R.id.editText_email);


        mLoginn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent loginnIntent = new Intent(Registrer.this,MainActivity.class);
                startActivity(loginnIntent);
            }
        });

        mRegistrer.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                String bruker = mBrukernavn.getText().toString().trim();
                String passord = mPassord.getText().toString().trim();
                String gjenta_passord = mGjentaPassord.getText().toString().trim();
                String navn = mNavn.getText().toString().trim();
                String email = mEmail.getText().toString().trim();
                if (passord.equals(gjenta_passord)){
                    long lagtTil = db.leggTilBruker(bruker, passord, navn, email);
                    if (lagtTil > 0){
                        Toast.makeText(Registrer.this, "Registrering vellyket", Toast.LENGTH_SHORT).show();
                        Intent tilLogin = new Intent(Registrer.this,MainActivity.class);
                        startActivity(tilLogin);
                    }
                    else{
                        Toast.makeText(Registrer.this, "Registrering mislyktes", Toast.LENGTH_SHORT).show();
                    }
                }
                else{
                    Toast.makeText(Registrer.this, "Passordet matcher ikke", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
