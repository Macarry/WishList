package com.example.semesteroppg.ui;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.ListView;
import android.widget.Toast;

import com.example.semesteroppg.MainActivity;
import com.example.semesteroppg.Profil;
import com.example.semesteroppg.R;


public class Hovedside extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hovedside);

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.meny, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logut:
                Intent loggeut = new Intent (Hovedside.this, MainActivity.class);
                startActivity(loggeut);
                Toast.makeText(this, "Logget ut", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.profil:
                Intent profil = new Intent (Hovedside.this, Profil.class);
                startActivity(profil);
                Toast.makeText(this, "Profil", Toast.LENGTH_SHORT).show();
                return true;
            default:
            return super.onOptionsItemSelected(item);
        }
    }
}
