package com.example.semesteroppg;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.example.semesteroppg.R;
import com.example.semesteroppg.ui.Database;
import com.example.semesteroppg.ui.Hovedside;
import com.example.semesteroppg.MainActivity;

import org.w3c.dom.Text;

public class Profil extends AppCompatActivity {
    Database db;


    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profil);

        TextView brukerid = findViewById(R.id.brukerid);
        TextView profil_brukernavn = findViewById(R.id.profil_navn);
        TextView fult_navn = findViewById(R.id.Navn);
        TextView email = findViewById(R.id.profil_email);

        SharedPreferences deltNavn = getSharedPreferences("minKey", MODE_PRIVATE);
        String lagretNavn = deltNavn.getString("lagretNavn", "");
        profil_brukernavn.setText(lagretNavn);

        db= new Database(this);
        Cursor info = db.skrivUtInfo();
        if(info.getCount()==0){
            Toast.makeText(getApplicationContext(), "Null informasjon", Toast.LENGTH_SHORT).show();
        }
        else{
            while(info.moveToNext()){
                brukerid.setText(info.getString(0));
                profil_brukernavn.setText(info.getString(1));
                fult_navn.setText(info.getString(3));
                email.setText(info.getString(4));
            }
        }
    }


    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.meny, menu);
        return true;
    }

    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logut:
                Intent loggeut = new Intent (Profil.this, MainActivity.class);
                startActivity(loggeut);
                Toast.makeText(this, "Logget ut", Toast.LENGTH_SHORT).show();
                return true;
            case R.id.hjem:
                Intent hjem = new Intent (Profil.this, Hovedside.class);
                startActivity(hjem);
                Toast.makeText(this, "Profil", Toast.LENGTH_SHORT).show();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
