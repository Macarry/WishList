package com.example.semesteroppg;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.semesteroppg.ui.Database;
import com.example.semesteroppg.ui.Hovedside;


public class MainActivity extends AppCompatActivity {
    Button mLoginn, mRegistrer;
    public static EditText mBrukernavn;
    EditText mPassord;
    Database db;
    public static String lagretNavn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        db = new Database(this);
        mLoginn = (Button)findViewById(R.id.button_loginn);
        mBrukernavn = (EditText)findViewById(R.id.editText_brukernavn);
        mPassord = (EditText)findViewById(R.id.editText_passord);
        mRegistrer = (Button)findViewById(R.id.button_registrer);

        mRegistrer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent registrerIntent = new Intent(MainActivity.this,Registrer.class);
                startActivity(registrerIntent);
            }
        });

        mLoginn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String bruker_sjekk = mBrukernavn.getText().toString().trim();
                String passord_sjekk = mPassord.getText().toString().trim();
                Boolean resultat = db.sjekkBruker(bruker_sjekk, passord_sjekk);
                if (resultat == true)
                {

                    lagretNavn = mBrukernavn.getText().toString();
                    SharedPreferences deltNavn = getSharedPreferences("minKey", MODE_PRIVATE);
                    SharedPreferences.Editor editor = deltNavn.edit();
                    editor.putString("lagretNavn", lagretNavn);
                    editor.apply();

                    Toast.makeText(MainActivity.this, "Vellykket loginn", Toast.LENGTH_SHORT).show();
                    Intent hovedside = new Intent (MainActivity.this, Hovedside.class);
                    startActivity(hovedside);
                }
                else
                {
                    Toast.makeText(MainActivity.this, "Error, kontroller at brukernavn/passord er riktig", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }


}
