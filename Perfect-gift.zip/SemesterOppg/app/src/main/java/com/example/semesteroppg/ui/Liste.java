package com.example.semesteroppg.ui;


import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.semesteroppg.R;

import java.util.List;

public class Liste {
    String name;
    List<Liste> mDrinks;

    public Liste(String name) {
        this.name = name;

    }

    public String getName() {
        return name;
    }

    public String toString() {
        String result;
        result = "Gave: " + this.name;
        return result;
    }

}


