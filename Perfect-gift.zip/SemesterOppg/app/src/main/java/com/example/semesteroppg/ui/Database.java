package com.example.semesteroppg.ui;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import static com.example.semesteroppg.MainActivity.lagretNavn;

public class Database extends SQLiteOpenHelper {
    public static final String db_navn="perfectgift.db";
    public static final String tabel_navn="bruker";
    public static final String kol_1="id";
    public static final String kol_2="brukernavn";
    public static final String kol_3="passord";



    public Database(@Nullable Context context) {
        super(context, db_navn, null, 3);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE bruker (id INTEGER PRIMARY KEY AUTOINCREMENT, brukernavn TEXT, passord TEXT, navn TEXT, email TEXT)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + tabel_navn);
        onCreate(sqLiteDatabase);
    }

    public long leggTilBruker(String bruker, String passord, String navn, String email){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues value = new ContentValues();
        value.put("Brukernavn", bruker);
        value.put("Passord", passord);
        value.put("Navn", navn);
        value.put("Email", email);
        long resultat = db.insert("bruker", null, value);
        db.close();
        return resultat;
    }

    public boolean sjekkBruker(String brukernavn, String passord){
        String[] columns = {kol_1};
        SQLiteDatabase db = getReadableDatabase();
        String valg = kol_2 + "=?" + " and " + kol_3 + "=?";
        String[] valgArgs = {brukernavn, passord};
        Cursor cursor = db.query(tabel_navn, columns, valg, valgArgs, null, null, null);
        int count = cursor.getCount();
        cursor.close();
        db.close();

        if (count>0)
            return true;
        else
            return false;
    }

    public Cursor skrivUtInfo(){
        SQLiteDatabase database = this.getReadableDatabase();
        Cursor info = database.rawQuery("select * from bruker where brukernavn LIKE '"+lagretNavn+"'", null);
        return info;
    }
}
